import json
import time as tm
from tkinter import *

# FirexOS initialization
print("Welcome to Alero Command")
print("Initializing system files...")

# Main session loop
session_online = True

# Virtual file system (in-memory representation)
files = {
    "boot.saf": "Alero.startup()",
    "main.mfe": "command = input(> )"
}

# Save files to backup.json
def save_files():
    try:
        with open("files.json", "w") as backup_file:
            json.dump(files, backup_file)
    except Exception as e:
        print(f"Error saving files: {e}")

# Boot system
def boot(message):
    print(message or "Booting system...")
    print("Type 'restore' to reset file system or 'reset' to reboot.")
    while True:
        c = input("~ ").strip().lower()
        if c == "restore":
            restore_files()
            save_files()
        elif c == "reset":
            if "boot.saf" in files:
                restore_files()
                break
            else:
                print("No bootable device found.")
        else:
            print("Invalid command.")
# Initialize clock system
def init_clock_sys():
    files["clock.sys"] = "Simulated OS Clock"

def clock():
    return tm.strftime("%H:%M:%S", tm.localtime())

def read_clock_sys():
    if "clock.sys" in files:
        return f"Current Time: {clock()}"
    return "clock.sys missing"

# System info
sysinfo = "Alero Command 1.0 (Testing)"
init_clock_sys()

# Helper functions
def commandexec(com):
    if command == "help":
        print(f'''\n# {sysinfo} Commands
- help: Displays help menu
- crt: Creates a new file
- read: Reads file content
- list: Lists all files
- del: Deletes a file
- wrt: Writes to a file
- sysinfo: Displays system info
- repair: Repairs missing or corrupted system files
- backup: Saves a backup of the current system state
- restore: Restores the system from the last backup
- ren: Renames a file
- echo: Outputs text
- time: Outputs the current time
- gui: Starts a testing GUI
- quit: Quits the current session''')
    elif command == "crt":
        file_name = input("Enter file name: ").strip()
        content = input(f"Enter content for '{file_name}': ")
        create_file(file_name, content)
        save_files()
    elif command == "del":
        file_name = input("Enter file name to delete: ").strip()
        if file_name == "sudo sys":
            confirm = input("Are you sure you want to delete all files? (y/n): ").strip().lower()
            if confirm.startswith("y"):
                files.clear()
                print("All files deleted.")
            else:
                print("Deletion aborted.")
        else:
            delete_file(file_name)
            save_files()
    elif command == "read":
        file_name = input("Enter file name to read: ").strip()
        display_file_contents(file_name)
    elif command == "list":
        list_files()
    elif command == "ren":
        old_name = input("Enter current file name: ").strip()
        new_name = input("Enter new file name: ").strip()
        rename_file(old_name, new_name)
        save_files()
    elif command == "wrt":
        file_name = input("Enter file name: ").strip()
        text = input("Enter text to write: ").strip()
        append = input("Append to file? (yes/no): ").strip().lower() == "yes"
        write_to_file(file_name, text, append)
        save_files()
    elif command == "backup":
        save_files()
    elif command == "restore":
        restore_files()
    elif command == "time":
        print(read_clock_sys())
    elif command.startswith("echo"):
        text = command[5:].strip()
        print(text)
    elif command == "quit":
        save_files()
        print("Exiting...")
        session_online = False
    elif command == "gui":
        print("Starting Development GUI")
        mainui()
    elif command == "boot":
        boot("")
    elif command.startswith("echo"):
        command.strip(3)
        print(command)
    else:
        print(f"Unknown command: {command}")
def mainui():
    print("mainui() function reached")
    root = Tk()
    root.title("Development GUI")
    print("Main window startup successful")
    root.mainloop()

def create_file(file_name, content=""):
    files[file_name] = content
    print(f"File '{file_name}' created.")

def delete_file(file_name):
    if file_name in files:
        del files[file_name]
        print(f"File '{file_name}' deleted.")
    else:
        print(f"File '{file_name}' not found.")

def display_file_contents(file_name):
    if file_name in files:
        print(f"Contents of '{file_name}':\n{files[file_name]}")
    else:
        print(f"File '{file_name}' not found.")

def list_files():
    if files:
        print("Listing files:")
        for file_name in files:
            print(f"- {file_name}")
    else:
        print("No files available.")

def rename_file(old_name, new_name):
    if old_name in files:
        files[new_name] = files.pop(old_name)
        print(f"File '{old_name}' renamed to '{new_name}'.")
    else:
        print(f"File '{old_name}' not found.")

def write_to_file(file_name, text, append=False):
    if file_name in files:
        if append:
            files[file_name] += "\n" + text
        else:
            files[file_name] = text
        print(f"Text written to '{file_name}'.")
    else:
        print(f"File '{file_name}' not found.")

def restore_files():
    global files
    try:
        with open("files.json", "r") as backup_file:
            files = json.load(backup_file)
    except Exception as e:
        print(f"Error restoring files: {e}")

# Restore saved files
restore_files()

if "boot.saf" in files:
    session_online = True
else:
    boot('"boot.saf" not found')

while session_online:
    if "main.mfe" not in files:
        boot('"main.mfe" not found')
        continue

    command = input("> ").strip().lower()
    save_files()
    commandexec(command)