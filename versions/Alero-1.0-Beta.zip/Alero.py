import json
import time as tm
import sys
import traceback
import os

def supports_ansi():
    term = os.getenv("TERM", "")
    return term in [
        "xterm", "xterm-256color", "rxvt", "rxvt-256color", "rxvt-unicode",
        "rxvt-unicode-256color", "screen", "screen-256color", "tmux", "tmux-256color",
        "linux", "linux-256color", "dtterm", "vt100", "vt102", "gnome-terminal", 
        "konsole", "eterm", "putty", "putty-256color", "st", "st-256color", "alacritty", 
        "termite", "kitty", "xfce4-terminal", "tilix", "mate-terminal", "terminator",
        "cmd", "powershell", "windows-terminal", "conemu", "git-bash", "cmder", "iterm2",
        "terminal", "hyper"
    ]

# check if the terminal suports ANSI
if supports_ansi():
    # Text Colors
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    ORANGE = "\033[1;33m"  # Bold Yellow as a substitute for Orange
    BLUE = "\033[34m"
    PURPLE = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bold Text Colors
    BOLD = "\033[1m"
    BOLD_RED = "\033[1;31m"
    BOLD_GREEN = "\033[1;32m"
    BOLD_YELLOW = "\033[1;33m"
    BOLD_BLUE = "\033[1;34m"
    BOLD_PURPLE = "\033[1;35m"
    BOLD_CYAN = "\033[1;36m"
    BOLD_WHITE = "\033[1;37m"

    # Background Colors
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_PURPLE = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"

    # Bold Background Colors
    BOLD_BG_RED = "\033[1;41m"
    BOLD_BG_GREEN = "\033[1;42m"
    BOLD_BG_YELLOW = "\033[1;43m"
    BOLD_BG_BLUE = "\033[1;44m"
    BOLD_BG_PURPLE = "\033[1;45m"
    BOLD_BG_CYAN = "\033[1;46m"
    BOLD_BG_WHITE = "\033[1;47m"

    # Reset (to normal text)
    RESET = "\033[0m"
else:
    print("                  ")
    print('WARNING: This terminal isnt listed under "SupportsColors"')
    comd = input("Do you wish to turn ANSI coloring on? [y/n]> ")
    if comd.startswith("y"):
        print("Turning on colors")
        # Text Colors
        RED = "\033[31m"
        GREEN = "\033[32m"
        YELLOW = "\033[33m"
        ORANGE = "\033[1;33m"
        BLUE = "\033[34m"
        PURPLE = "\033[35m"
        CYAN = "\033[36m"
        WHITE = "\033[37m"

        # Bold Text Colors
        BOLD = "\033[1m"
        BOLD_RED = "\033[1;31m"
        BOLD_GREEN = "\033[1;32m"
        BOLD_YELLOW = "\033[1;33m"
        BOLD_BLUE = "\033[1;34m"
        BOLD_PURPLE = "\033[1;35m"
        BOLD_CYAN = "\033[1;36m"
        BOLD_WHITE = "\033[1;37m"

        # Background Colors
        BG_RED = "\033[41m"
        BG_GREEN = "\033[42m"
        BG_YELLOW = "\033[43m"
        BG_BLUE = "\033[44m"
        BG_PURPLE = "\033[45m"
        BG_CYAN = "\033[46m"
        BG_WHITE = "\033[47m"

        # Bold Background Colors
        BOLD_BG_RED = "\033[1;41m"
        BOLD_BG_GREEN = "\033[1;42m"
        BOLD_BG_YELLOW = "\033[1;43m"
        BOLD_BG_BLUE = "\033[1;44m"
        BOLD_BG_PURPLE = "\033[1;45m"
        BOLD_BG_CYAN = "\033[1;46m"
        BOLD_BG_WHITE = "\033[1;47m"

        # Reset (to normal text)
        RESET = "\033[0m"
    else:
        print("colors turned off completely.")
        RED = ""
        GREEN = ""
        YELLOW = ""
        ORANGE = ""
        BLUE = ""
        PURPLE = ""
        CYAN = ""
        WHITE = ""
        BOLD = ""
        BOLD_RED = ""
        BOLD_GREEN = ""
        BOLD_YELLOW = ""
        BOLD_BLUE = ""
        BOLD_PURPLE = ""
        BOLD_CYAN = ""
        BOLD_WHITE = ""
        BG_RED = ""
        BG_GREEN = ""
        BG_YELLOW = ""
        BG_BLUE = ""
        BG_PURPLE = ""
        BG_CYAN = ""
        BG_WHITE = ""
        BOLD_BG_RED = ""
        BOLD_BG_GREEN = ""
        BOLD_BG_YELLOW = ""
        BOLD_BG_BLUE = ""
        BOLD_BG_PURPLE = ""
        BOLD_BG_CYAN = ""
        BOLD_BG_WHITE = ""
        RESET = ""


# FirexOS initialization
print(f"{BOLD_BLUE}Welcome to Alero Command! {RESET}")
print("Initializing system files...")

# System Information
name = "Alero "
type = "Command "
version = "1.0 "
spcl = "Beta"
sysinfo = (name + type + version + spcl)

# Main stuff
session_online = True
files = {}
installed_packages = {}

# Helper functions
def progress_bar(duration):
    """Creates a progress bar that updates over `duration` seconds."""
    bar_length = 20  # Length of the bar
    for i in range(bar_length + 1):
        percent = (i / bar_length) * 100
        bar = "#" * i + "-" * (bar_length - i)
        sys.stdout.write(f"\r[{bar}] {percent:.0f}%")
        sys.stdout.flush()
        tm.sleep(duration / bar_length)
    print()  # Move to the next line

def pkginstall(pkgname, installed_packages):
    print("Starting installation...")
    pkgname = pkgname.lower()  # Make case-insensitive

    if pkgname in ["test", "sysinfo"]:
        print("Setting up installation modules...")
        tm.sleep(0.8)
        print('Running "pkginstallhandler.main"...')
        tm.sleep(0.5)

        command = input("Do you proceed to install? [y/n]> ").strip().lower() or "n"
        
        if command.startswith("y"):
            print(f'Installing package "{pkgname.capitalize()}"...')
            progress_bar(1)
            tm.sleep(0.15)
            print("Setting up comd module...")
            progress_bar(0.1)
            tm.sleep(0.2)
            print("Installing dependencies...")
            progress_bar(1.5)
            tm.sleep(0.15)
            installed_packages[pkgname] = True
            print(f'Successfully installed "{pkgname.capitalize()}" package.')
        else:
            print('Aborting "pkginstallhandler"...')
            tm.sleep(0.2)
            print("Installation aborted.")
    else:
        print(f'Error: Package "{pkgname}" not found.')


def pkgremove(pkgname, installed_packages):
    pkgname = pkgname.lower()  # Normalize input

    if pkgname in installed_packages and installed_packages[pkgname]:
        print("Setting up modules...")
        tm.sleep(0.4)
        print('Running "pkgremovehandler.main"...')
        tm.sleep(0.3)

        command = input("Do you proceed to remove? [y/n]> ").strip().lower() or "n"
        
        if command.startswith("y"):
            print(f'Removing package "{pkgname.capitalize()}"...')
            progress_bar(1.4)
            tm.sleep(0.5)
            print("Deleting command...")
            tm.sleep(0.1)
            print("Deleting dependencies...")
            progress_bar(0.7)
            tm.sleep(0.2)
            installed_packages[pkgname] = False  # Mark as uninstalled
            print(f'Successfully removed "{pkgname.capitalize()}" package.')
        else:
            print(f'Error: Package "{pkgname}" is not installed.')

def timey():
    clock = tm.strftime("%H:%M:%S", tm.localtime())
    return f"Current Time: {clock}"
def sysinfor():
    print(f'''
    Name: {name}
    Type: {type}
    Version: {version}
    Release: {spcl}
    ''')
def restart_alero():
    print("Restarting Alero Command...")
    os.execv(sys.executable, [sys.executable] + sys.argv)

# File manipulation
def create_file(file_name, content=""):
    # Split the path into components
    global command
    path = command
    path_parts = path.strip("/").split("/")
    
    current_directory = files["main"]["files"]
    
    # Navigate through the path
    for part in path_parts[:-1]:
        # Check if the part exists and is a directory
        if part in current_directory and isinstance(current_directory[part], dict):
            current_directory = current_directory[part]
        else:
            print(f"Error: The path {part} does not exist.")
            return
    
    # The final part is the file or folder we want to create
    new_item = path_parts[-1]
    if file_name not in current_directory:
        current_directory[file_name] = f"{content}"
        print(f"Created: {file_name}")
    else:
        print(f"Error: {file_name} already exists.")

def delete_file(file_name):
    if file_name in files["main"]:
        del files["main"][file_name]
        print(f"File '{file_name}' deleted.")
    else:
        print(f"File '{file_name}' not found.")

def display_file_contents(file_name):
    if file_name in files:
        print(f"Contents of '{file_name}':\n{files[file_name]}")
    else:
        print(f"File '{file_name}' not found.")


def list_files(path=""):
    if path == "":
        path = current_directory  # Default to current directory
    parts = path.split("/") if path else ["main"]
    current = files

    for part in parts:
        if part in current and isinstance(current[part], dict):
            current = current[part]
        else:
            print(f"Path '{path}' not found.")
            return

    if current:
        print(f"Contents of '{path}':")
        for name in current:
            print(f" - {name}")
    else:
        print(f"Contents of '{path}': (empty)")

def rename_file(old_name, new_name):
    if old_name in files:
        files[new_name] = files.pop(old_name)
        print(f"File '{old_name}' renamed to '{new_name}'.")
    else:
        print(f"File '{old_name}' not found.")

def write_to_file(file_name, text, append=False):
    if file_name in files["main"]:
        if append:
            files["main"][file_name] += "\n" + text
        else:
            files["main"][file_name] = text
        print(f"Text written to '{file_name}'.")
    else:
        print(f"File '{file_name}' not found.")

def load_files():
    try:
        with open("files.json", "r") as backup_file:
            return json.load(backup_file)
    except FileNotFoundError:
        print("No previous files found, using default system build.")
        return {
            "main": {
                "files": {},
                "packages": {}
            }
        }
    except Exception as e:
        print(f"Error loading files: {e}")
        return {}

def restore_files():
    global files
    files = load_files()

def save_files():
    try:
        with open("files.json", "w") as backup_file:
            json.dump(files, backup_file, indent=4)
    except Exception as e:
        print(f"Error saving files: {e}")

# Directory stuff
current_directory = "main/files"

def change_localdir(path):
    global current_directory
    parts = path.split("/") if path else []

    current = files

    # Traverse the path
    for part in parts:
        if part in current and isinstance(current[part], dict):
            current = current[part]
        else:
            print(f"Path '{path}' not found.")
            return

    # Update current directory
    current_directory = path
    print(f"Changed directory to '/{current_directory}'")


# Boot system
def boot(message):
    print("i am sorry but this feature is still in development.")
    print('Returning back to "commandexec"')
    commandexec("echo returned succesfully")

# Main Command Executor (MCE)
def commandexec(command):
    save_files()
    admin = False
    if str(command).startswith("main"):
        admin = True
        command = str(command).strip("main ")
    # Command list
    # Default commands
    if command == "help":
        print(f'''\n# {sysinfo} Commands
- main: is a prefix you can use to execute priviliged commands
- help: Displays a help menu
- crt: Creates a new file
- read: Reads a files content
- lsx: Lists all files
- del: Deletes a file
- wrt: Writes to a file
- ren: Renames a file
- echo: Outputs text
- time: Outputs the current time
- apm: lets you download packages via the Alero Package manager
- quit: Quits the current session
- cacs: Custom Alero Calculator script used to calculate stuff
* Package commands
- sysinfo: Displays system info
- test: does completely nothing. good for debugging
              ''')
    elif command == "crt":
        file_name = input("Enter file name: ").strip()
        content = input(f"Enter content for '{file_name}': ")
        create_file(file_name, content)
        save_files()
    elif command == "del":
        print("Enter file name to delete:")
        file_name = input("del.name> ").strip()
        if file_name == "/":
            print("Are you sure you want to delete all files? (y/n):")
            confirm = input("del.cnfrm> ").strip().lower()
            if confirm.startswith("y") and admin:
                files.clear()
                print("All files deleted.")
            else:
                print("Deletion aborted.")
        else:
            delete_file(file_name)
            save_files()
    elif command == "read":
        print("Enter file name to read:")
        file_name = input("read> ").strip()
        display_file_contents(file_name)
    elif command.startswith("lsx"):  # Make sure there's a space after 'list'
        path = command[4:].strip()  # Extract the path correctly
        if not path == "":
            list_files(path)
        else:
            list_files("main")
    elif command == "ren":
        print("Enter current file name:")
        old_name = input("ren> ").strip()
        print("Enter new file name:")
        new_name = input("ren> ").strip()
        rename_file(old_name, new_name)
        save_files()
    elif command == "wrt":
        print()
        file_name = input("Enter file name: ").strip()
        print()
        text = input("Enter text to write: ").strip()
        print()
        append = input("Append to file? (yes/no): ").strip().lower()
        if append.startswith("y"):
            write_to_file(file_name, text, append)
            save_files()
            print("append succesfull.")
        else:
            print("append aborted.")
    elif command == "time":
        print(timey())
    elif command.startswith("echo"):
        text = command[5:].strip()
        print(text)
    elif command == "quit":
        save_files()
        print("Exiting...")
        global session_online
        session_online = False
    elif command == "boot":
        boot("")
    elif command.startswith("echo"):
        command.strip(3)
        print(command)
    elif command == ("apm"):
        print("type del or new")
        command = input("apm> ")
        if command == "new":
            print("Please insert package name")
            command = input("apm.name> ")
            pkginstall(f"{command}", installed_packages)
        if command == "del":
            print("Please insert package name")
            command = input("apm.name> ")
            tm.sleep(0.2)
            pkgremove(command, installed_packages)
    elif command.startswith("clp"):
        path = command.strip("clp").strip()
        change_localdir(path)

    # Package commands
    elif command == "sysinfo":
        if "sysinfo" in installed_packages and installed_packages["sysinfo"]:
            sysinfor()
        else:
            print(f'Unknown command: {command}, try installing the "sysinfo" package.')

    elif command == "test":
        if "test" in installed_packages and installed_packages["test"]:
            print("This is a testing package. It will eventually be removed.")
        else:
            print(f'Unknown command: {command}, try installing the "test" package.')
    elif command == "cacs":
        print("Welcome to CACS!")
        print("(Custom Alero Calculator Script)")
        print("Type exit to exit CACS")
        print("Please enter your expression:")
        cacs_online = True
        while cacs_online:
            command = input("cacs> ")
            if command == "exit":
                print("Exiting")
                cacs_online = False
            else:  
                try:
                    # Evaluate the expression
                    result = eval(command)
                    print("Result:", result)
                except ZeroDivisionError:
                    print("Error: Division by zero!")
                except Exception as e:
                    print(f"Error: {e}")
    elif command == "rst":
        restart_alero()
# Error handler
    else:
        print(f"Unknown command: {command}")

# Restore saved files
restore_files()
save_files()

while session_online:
    try:
        command = input(f"{BOLD_GREEN}/{YELLOW}{current_directory}{CYAN}>{RESET} ").strip().lower()
        commandexec(command)
    except Exception as e:
        emsg = traceback.format_exc()
        os.system('cls' if os.name == "nt" else 'clear')
        print("-" * 40)
        print(f"{BG_RED}               TBES                    ")
        print(f"       Text Based Error Screen         {RESET}")
        print("-" * 40)
        print("An unexpected error has occurred:")
        print(f"Error: {str(e)}")
        print("\nDetailed traceback:")
        print(emsg)
        print("_" * 40)
        input("\nPress Enter to continue...")  # Keeps it open